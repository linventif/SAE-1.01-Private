Trinôme: S1-A
-Engelaere Théo
-Grégoire Launay-Becue
-Rafael Piral

Dépendance : program.jar & default-jdk
Compiler le programe : javac -cp ../program.jar:. SAEpolybe_LaunayBecue_Piral_Engelaere.java
Executer le programe : java -cp ../program.jar:. SAEpolybe_LaunayBecue_Piral_Engelaere

POUR DECODER UN MESSAGE:
assurez-vous de ne pas oublier un espace à la fin de votre message
ex: "01 02 43 12 "
